package com.example.demo.Service;

import com.example.demo.Models.Productos;

import java.util.List;

public interface IProductosService {

    List<Productos> getProductos();

    Productos nuevoProducto(Productos producto);
    Productos buscarProducto(Long id);
    Productos actualizarProducto(Productos producto);
    void borrarProducto(Long id);

}
