package com.example.demo.Controller;


import com.example.demo.Models.Productos;
import com.example.demo.Service.ProductosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductosController {

    @Autowired
    ProductosService productosService;


    @GetMapping("/list")
    public List<Productos> getProductos() {
        return productosService.getProductos();
    }

    @GetMapping("/list/{id}")
    public Productos getProducto(@PathVariable Long id) {
        return productosService.buscarProducto(id);
    }

    @PostMapping("/")
    public ResponseEntity<Productos> nuevoProducto(@RequestBody Productos producto) {
        producto.setId(null);
        Productos obj = productosService.nuevoProducto(producto);
        return new ResponseEntity<>(obj, HttpStatus.CREATED);
    }


    @PutMapping("/")
    public ResponseEntity<Productos> actualizarProducto(@RequestBody Productos producto) {
        Productos obj = productosService.buscarProducto(producto.getId());
        if (obj != null) {
            obj.setNombre(producto.getNombre());
            obj.setIvaCompra(producto.getIvaCompra());
            obj.setPrecioCompra(producto.getPrecioCompra());
            obj.setPrecioVenta(producto.getPrecioVenta());

            Productos actualizado = productosService.nuevoProducto(obj);
            return new ResponseEntity<>(actualizado, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrarProducto(@PathVariable Long id) {
        Productos obj = productosService.buscarProducto(id);
        if (obj != null) {
            productosService.borrarProducto(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
