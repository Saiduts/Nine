package com.example.demo.Service;

import com.example.demo.Models.Proveedor;
import com.example.demo.Repository.ProveedorRepositorio;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
public class ProveedorService implements IProveedorService {
    @Autowired
    ProveedorRepositorio proveedorRepositorio;

    @Override
    public List<Proveedor> getProveedor() {
        return proveedorRepositorio.findAll();
    }

    @Override
    public Proveedor nuevoProveedor(Proveedor proveedor) {
        return proveedorRepositorio.save(proveedor);
    }

    @Override
    public Proveedor actualizarProveedor(Proveedor proveedor) {
        return proveedorRepositorio.save(proveedor);
    }

    @Override
    public Proveedor buscarProveedor(Long id) {
        Proveedor proveedor = null;
        proveedor = proveedorRepositorio.findById(id).orElse(null);
        if (proveedor == null) {
            return null;
        }
        return proveedor;
    }

    @Override
    public void borrarProveedor(Long id) {
        proveedorRepositorio.deleteById(id);
    }

}
