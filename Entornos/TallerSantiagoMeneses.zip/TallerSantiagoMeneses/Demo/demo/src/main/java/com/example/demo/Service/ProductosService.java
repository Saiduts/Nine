package com.example.demo.Service;

import com.example.demo.Models.Productos;
import com.example.demo.Repository.ProductosRepositorio;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Service
@Transactional
public class ProductosService implements IProductosService {

    @Autowired
    ProductosRepositorio productosRepositorio;

    @Override
    public List<Productos> getProductos() {
        return productosRepositorio.findAll();
    }

    public Productos getProducto(Long id) {
        return productosRepositorio.findById(id).get();
    }

    @Override
    public Productos nuevoProducto(Productos producto) {
        return productosRepositorio.save(producto);
    }

    @Override
    public Productos actualizarProducto(Productos producto) {
        return productosRepositorio.save(producto);
    }

    @Override
    public Productos buscarProducto(Long id) {
        Productos producto = null;
        producto = productosRepositorio.findById(id).orElse(null);
        if (producto == null) {
            return null;
        }
        return producto;
    }

    @Override
    public void borrarProducto(Long id) {
        productosRepositorio.deleteById(id);
    }
}
