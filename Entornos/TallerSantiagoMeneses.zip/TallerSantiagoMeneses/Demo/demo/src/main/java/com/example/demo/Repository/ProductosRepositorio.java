package com.example.demo.Repository;

import com.example.demo.Models.Productos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductosRepositorio extends JpaRepository<Productos, Long> {
}
