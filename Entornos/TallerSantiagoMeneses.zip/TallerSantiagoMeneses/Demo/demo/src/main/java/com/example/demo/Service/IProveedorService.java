package com.example.demo.Service;

import com.example.demo.Models.Proveedor;

import java.util.List;

public interface IProveedorService {
    List<Proveedor> getProveedor();

    Proveedor nuevoProveedor(Proveedor proveedor);

    Proveedor buscarProveedor(Long id);

    Proveedor actualizarProveedor(Proveedor proveedor);

    void borrarProveedor(Long id);
}
